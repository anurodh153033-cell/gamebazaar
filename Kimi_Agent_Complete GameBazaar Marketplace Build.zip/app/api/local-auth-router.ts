import { z } from "zod";
import * as cookie from "cookie";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { passwordResetTokens, users } from "@db/schema";
import {
  hashPassword,
  verifyPassword,
  sha256,
  randomCode,
} from "./lib/crypto";
import { signSessionToken } from "./kimi/session";
import { getSessionCookieOptions } from "./lib/cookies";
import { Session } from "@contracts/constants";
import { env } from "./lib/env";
import { rateLimit, clientIp } from "./lib/ratelimit";
import { ensureWallet, publicUser } from "./lib/helpers";

const emailSchema = z.string().trim().toLowerCase().email().max(320);
const passwordSchema = z.string().min(8, "Password must be at least 8 characters").max(100);

async function issueSession(ctx: { resHeaders: Headers; req: Request }, unionId: string) {
  const token = await signSessionToken({ unionId, clientId: env.appId });
  const opts = getSessionCookieOptions(ctx.req.headers);
  ctx.resHeaders.append(
    "set-cookie",
    cookie.serialize(Session.cookieName, token, {
      httpOnly: opts.httpOnly,
      path: opts.path,
      sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
      secure: opts.secure,
      maxAge: Session.maxAgeMs / 1000,
    }),
  );
}

export const localAuthRouter = createRouter({
  signup: publicQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(80),
        email: emailSchema,
        password: passwordSchema,
        accountType: z.enum(["buyer", "seller", "both"]).default("both"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      rateLimit(`signup:${clientIp(ctx.req.headers)}`, 10, 60_000);
      const db = getDb();
      const existing = await db.query.users.findFirst({
        where: eq(users.unionId, `local:${input.email}`),
      });
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });
      }
      await db.insert(users).values({
        unionId: `local:${input.email}`,
        name: input.name,
        email: input.email,
        passwordHash: hashPassword(input.password),
        accountType: input.accountType,
        lastSignInAt: new Date(),
      });
      const user = await db.query.users.findFirst({
        where: eq(users.unionId, `local:${input.email}`),
      });
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await ensureWallet(user.id);
      await issueSession(ctx, user.unionId);
      return publicUser(user);
    }),

  login: publicQuery
    .input(z.object({ email: emailSchema, password: z.string().max(100) }))
    .mutation(async ({ ctx, input }) => {
      rateLimit(`login:${clientIp(ctx.req.headers)}`, 15, 60_000);
      rateLimit(`login:${input.email}`, 10, 60_000);
      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.unionId, `local:${input.email}`),
      });
      if (!user?.passwordHash || !verifyPassword(input.password, user.passwordHash)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });
      }
      if (user.status === "banned") {
        throw new TRPCError({ code: "FORBIDDEN", message: "This account has been banned." });
      }
      if (user.status === "suspended") {
        throw new TRPCError({ code: "FORBIDDEN", message: "This account is suspended. Contact support." });
      }
      await db.update(users).set({ lastSignInAt: new Date() }).where(eq(users.id, user.id));
      await issueSession(ctx, user.unionId);
      return publicUser(user);
    }),

  // Step 1: request a reset code. Email delivery is not configured in this
  // deployment, so the code is returned in the response (single-use, 15 min TTL).
  requestPasswordReset: publicQuery
    .input(z.object({ email: emailSchema }))
    .mutation(async ({ ctx, input }) => {
      rateLimit(`reset:${clientIp(ctx.req.headers)}`, 5, 60_000);
      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.unionId, `local:${input.email}`),
      });
      // Do not leak account existence for unknown emails
      if (!user?.passwordHash) {
        return { sent: true, devCode: null as string | null };
      }
      const code = randomCode(6);
      await db.insert(passwordResetTokens).values({
        userId: user.id,
        codeHash: sha256(code),
        expiresAt: new Date(Date.now() + 15 * 60_000),
      });
      return { sent: true, devCode: code as string | null };
    }),

  // Step 2: reset with code
  resetPassword: publicQuery
    .input(
      z.object({
        email: emailSchema,
        code: z.string().length(6),
        password: passwordSchema,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      rateLimit(`reset2:${clientIp(ctx.req.headers)}`, 10, 60_000);
      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.unionId, `local:${input.email}`),
      });
      if (!user) throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid or expired code." });
      const tokens = await db.query.passwordResetTokens.findMany({
        where: eq(passwordResetTokens.userId, user.id),
      });
      const match = tokens.find(
        (t) => !t.usedAt && t.expiresAt > new Date() && t.codeHash === sha256(input.code),
      );
      if (!match) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid or expired code." });
      }
      await db
        .update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(eq(passwordResetTokens.id, match.id));
      await db
        .update(users)
        .set({ passwordHash: hashPassword(input.password) })
        .where(eq(users.id, user.id));
      return { success: true };
    }),

  changePassword: authedQuery
    .input(z.object({ current: z.string(), password: passwordSchema }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user = await db.query.users.findFirst({ where: eq(users.id, ctx.user.id) });
      if (user?.passwordHash) {
        if (!verifyPassword(input.current, user.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Current password is incorrect." });
        }
      }
      await db
        .update(users)
        .set({ passwordHash: hashPassword(input.password) })
        .where(eq(users.id, ctx.user.id));
      return { success: true };
    }),
});
