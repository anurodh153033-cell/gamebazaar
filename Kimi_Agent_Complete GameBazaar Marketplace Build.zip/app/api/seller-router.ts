import { z } from "zod";
import { and, desc, eq, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  listings,
  orders,
  reviews,
  users,
  wallets,
  walletTransactions,
  withdrawals,
} from "@db/schema";
import { encryptSecret } from "./lib/crypto";
import { ensureWallet } from "./lib/helpers";
import { getSetting, SETTING_KEYS, toPaise, toRupees } from "./lib/settings";
import { assertActive } from "./lib/procedures";

const listingInput = z.object({
  gameId: z.number().int().positive(),
  title: z.string().trim().min(5, "Title must be at least 5 characters").max(200),
  price: z.number().positive("Price must be greater than 0").max(10_000_000),
  description: z.string().trim().min(10, "Describe the account in at least 10 characters").max(5000),
  accountLevel: z.string().trim().max(60).optional(),
  trophiesRank: z.string().trim().max(120).optional(),
  skinsItems: z.string().trim().max(2000).optional(),
  screenshots: z.array(z.string().max(600)).max(8).default([]),
  otherInfo: z.string().trim().max(2000).optional(),
  deliveryMethod: z.enum(["manual", "automatic"]),
  deliveryCredentials: z.string().max(4000).optional(), // plaintext, encrypted server-side
});

async function ownedListing(db: ReturnType<typeof getDb>, id: number, sellerId: number) {
  const l = await db.query.listings.findFirst({ where: eq(listings.id, id) });
  if (!l || l.sellerId !== sellerId) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Listing not found or not yours." });
  }
  return l;
}

export const sellerRouter = createRouter({
  createListing: authedQuery.input(listingInput).mutation(async ({ ctx, input }) => {
    assertActive(ctx.user);
    const db = getDb();
    if (!["seller", "both"].includes(ctx.user.accountType)) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Enable selling on your profile first." });
    }
    if (input.deliveryMethod === "automatic" && !input.deliveryCredentials?.trim()) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "Automatic delivery requires the account credentials.",
      });
    }
    const autoApprove = (await getSetting(SETTING_KEYS.listingAutoApprove)) === "true";
    const listingsEnabled = (await getSetting(SETTING_KEYS.listingsEnabled)) === "true";
    if (!listingsEnabled) {
      throw new TRPCError({ code: "FORBIDDEN", message: "New listings are temporarily disabled by the marketplace." });
    }
    const { deliveryCredentials, screenshots, ...rest } = input;
    const [{ id }] = await db
      .insert(listings)
      .values({
        ...rest,
        price: input.price.toFixed(2),
        sellerId: ctx.user.id,
        screenshots: JSON.stringify(screenshots),
        deliveryCredentialsEnc: deliveryCredentials?.trim()
          ? encryptSecret(deliveryCredentials.trim())
          : null,
        status: autoApprove ? "active" : "pending",
      })
      .$returningId();
    return { id, status: autoApprove ? "active" : "pending" };
  }),

  updateListing: authedQuery
    .input(z.object({ id: z.number().int().positive() }).merge(listingInput.partial()))
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const l = await ownedListing(db, input.id, ctx.user.id);
      if (["sold", "removed"].includes(l.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This listing can no longer be edited." });
      }
      const { id, deliveryCredentials, screenshots, price, ...rest } = input;
      const patch: Record<string, unknown> = { ...rest };
      if (price != null) patch.price = price.toFixed(2);
      if (screenshots) patch.screenshots = JSON.stringify(screenshots);
      if (deliveryCredentials?.trim()) patch.deliveryCredentialsEnc = encryptSecret(deliveryCredentials.trim());
      // Sold-out flow: editing a reserved listing is allowed only for credentials
      if (l.status === "reserved" && Object.keys(patch).some((k) => k !== "deliveryCredentialsEnc")) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Listing is locked by an active order — only delivery credentials can be updated.",
        });
      }
      await db.update(listings).set(patch).where(eq(listings.id, id));
      return { ok: true };
    }),

  removeCredentials: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const l = await ownedListing(db, input.id, ctx.user.id);
      // Block removal once an order for this listing is in flight past payment
      const activeOrders = await db.query.orders.findMany({
        where: and(
          eq(orders.listingId, l.id),
          inArray(orders.status, ["payment_verified", "delivered"]),
        ),
      });
      if (activeOrders.length > 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Credentials are locked while an order is in delivery.",
        });
      }
      await db.update(listings).set({ deliveryCredentialsEnc: null }).where(eq(listings.id, l.id));
      return { ok: true };
    }),

  deleteListing: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const l = await ownedListing(db, input.id, ctx.user.id);
      if (l.status === "reserved") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Listing is locked by an active order." });
      }
      await db.update(listings).set({ status: "removed" }).where(eq(listings.id, l.id));
      return { ok: true };
    }),

  myListings: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.query.listings.findMany({
      where: eq(listings.sellerId, ctx.user.id),
      orderBy: [desc(listings.createdAt)],
    });
    const gameRows = await db.query.games.findMany();
    const gameMap = new Map(gameRows.map((g) => [g.id, g]));
    return rows.map((l) => ({
      ...l,
      deliveryCredentialsEnc: undefined,
      hasCredentials: !!l.deliveryCredentialsEnc,
      screenshots: JSON.parse(l.screenshots ?? "[]") as string[],
      game: gameMap.get(l.gameId) ?? null,
    }));
  }),

  mySales: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.query.orders.findMany({
      where: eq(orders.sellerId, ctx.user.id),
      orderBy: [desc(orders.createdAt)],
    });
    return Promise.all(
      rows.map(async (o) => {
        const l = await db.query.listings.findFirst({ where: eq(listings.id, o.listingId) });
        const buyer = await db.query.users.findFirst({ where: eq(users.id, o.buyerId) });
        return { ...o, listingTitle: l?.title ?? "—", buyerName: buyer?.name ?? "—" };
      }),
    );
  }),

  wallet: authedQuery.query(async ({ ctx }) => {
    const w = await ensureWallet(ctx.user.id);
    const minWithdrawal = await getSetting(SETTING_KEYS.minWithdrawal);
    return { ...w, minWithdrawal };
  }),

  transactions: authedQuery.query(async ({ ctx }) => {
    await ensureWallet(ctx.user.id);
    return getDb().query.walletTransactions.findMany({
      where: eq(walletTransactions.userId, ctx.user.id),
      orderBy: [desc(walletTransactions.createdAt)],
      limit: 100,
    });
  }),

  requestWithdrawal: authedQuery
    .input(
      z.object({
        amount: z.number().positive().max(10_000_000),
        method: z.enum(["upi", "airtel", "crypto"]),
        destination: z.string().trim().min(4).max(255),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const withdrawalsEnabled = (await getSetting(SETTING_KEYS.withdrawalsEnabled)) === "true";
      if (!withdrawalsEnabled) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Withdrawals are temporarily disabled by the marketplace." });
      }
      const min = Number(await getSetting(SETTING_KEYS.minWithdrawal));
      if (input.amount < min) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Minimum withdrawal is ₹${min}.` });
      }
      const w = await ensureWallet(ctx.user.id);
      const available = toPaise(w.availableBalance);
      const amountPaise = toPaise(input.amount);
      if (amountPaise > available) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient available balance." });
      }
      await db.transaction(async (tx) => {
        await tx
          .update(wallets)
          .set({ availableBalance: toRupees(available - amountPaise) })
          .where(eq(wallets.userId, ctx.user.id));
        await tx.insert(walletTransactions).values({
          userId: ctx.user.id,
          type: "withdrawal",
          amount: toRupees(-amountPaise),
          balanceAfter: toRupees(available - amountPaise),
          note: `Withdrawal request via ${input.method}`,
        });
        await tx.insert(withdrawals).values({
          userId: ctx.user.id,
          amount: toRupees(amountPaise),
          method: input.method,
          destination: input.destination,
        });
      });
      return { ok: true };
    }),

  myWithdrawals: authedQuery.query(async ({ ctx }) => {
    return getDb().query.withdrawals.findMany({
      where: eq(withdrawals.userId, ctx.user.id),
      orderBy: [desc(withdrawals.createdAt)],
      limit: 100,
    });
  }),

  myReviews: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.query.reviews.findMany({
      where: eq(reviews.sellerId, ctx.user.id),
      orderBy: [desc(reviews.createdAt)],
      limit: 50,
    });
    return Promise.all(
      rows.map(async (r) => {
        const reviewer = await db.query.users.findFirst({ where: eq(users.id, r.reviewerId) });
        return { ...r, reviewerName: reviewer?.name ?? "Buyer" };
      }),
    );
  }),

  earnings: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const w = await ensureWallet(ctx.user.id);
    const completedOrders = await db.query.orders.findMany({
      where: and(eq(orders.sellerId, ctx.user.id), eq(orders.status, "completed")),
    });
    const pendingOrders = await db.query.orders.findMany({
      where: and(
        eq(orders.sellerId, ctx.user.id),
        inArray(orders.status, ["payment_verified", "delivered"]),
      ),
    });
    return {
      wallet: w,
      completedCount: completedOrders.length,
      pendingDeliveryCount: pendingOrders.length,
      totalEarnings: w.totalEarnings,
    };
  }),
});
