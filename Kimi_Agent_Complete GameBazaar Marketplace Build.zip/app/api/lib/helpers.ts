import { getDb } from "../queries/connection";
import {
  auditLogs,
  credentialAccessLogs,
  notifications,
  wallets,
  type User,
} from "@db/schema";
import { eq } from "drizzle-orm";

/** Strip secrets (password hash) from a user row before returning it via API. */
export function publicUser<T extends User | null | undefined>(u: T) {
  if (!u) return u;
  const { passwordHash: _drop, ...rest } = u;
  return rest;
}

export async function notify(
  userId: number,
  title: string,
  body?: string,
  link?: string,
) {
  await getDb().insert(notifications).values({ userId, title, body, link });
}

export async function audit(
  adminId: number,
  action: string,
  targetType?: string,
  targetId?: string | number,
  detail?: string,
) {
  await getDb().insert(auditLogs).values({
    adminId,
    action,
    targetType,
    targetId: targetId != null ? String(targetId) : undefined,
    detail,
  });
}

export async function logCredentialAccess(
  adminId: number,
  orderId: number,
  listingId: number,
) {
  await getDb()
    .insert(credentialAccessLogs)
    .values({ adminId, orderId, listingId });
  await audit(adminId, "credential.view", "order", orderId, `listing #${listingId}`);
}

export async function ensureWallet(userId: number) {
  const db = getDb();
  const existing = await db.query.wallets.findFirst({
    where: eq(wallets.userId, userId),
  });
  if (existing) return existing;
  await db.insert(wallets).values({ userId });
  return (await db.query.wallets.findFirst({
    where: eq(wallets.userId, userId),
  }))!;
}
