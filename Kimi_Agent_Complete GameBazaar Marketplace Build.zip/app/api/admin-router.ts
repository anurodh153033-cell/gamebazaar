import { z } from "zod";
import { desc, eq, or } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  auditLogs,
  credentialAccessLogs,
  disputes,
  games,
  listings,
  messages,
  orders,
  users,
  wallets,
  walletTransactions,
  withdrawals,
} from "@db/schema";
import { decryptSecret } from "./lib/crypto";
import { audit, logCredentialAccess, notify } from "./lib/helpers";
import {
  getPaymentMethods,
  getSetting,
  setSetting,
  SETTING_KEYS,
  toPaise,
  toRupees,
} from "./lib/settings";
import { settleOrder } from "./order-router";

export const adminRouter = createRouter({
  // ---------- Dashboard ----------
  stats: adminQuery.query(async () => {
    const db = getDb();
    const allUsers = await db.query.users.findMany();
    const allOrders = await db.query.orders.findMany();
    const activeListings = await db.query.listings.findMany({
      where: eq(listings.status, "active"),
    });
    const completed = allOrders.filter((o) => o.status === "completed");
    const revenue = completed.reduce((s, o) => s + toPaise(o.platformFee), 0);
    const pendingWithdrawals = await db.query.withdrawals.findMany({
      where: eq(withdrawals.status, "pending"),
    });
    return {
      totalUsers: allUsers.length,
      buyers: allUsers.filter((u) => ["buyer", "both"].includes(u.accountType)).length,
      sellers: allUsers.filter((u) => ["seller", "both"].includes(u.accountType)).length,
      activeListings: activeListings.length,
      soldListings: (await db.query.listings.findMany({ where: eq(listings.status, "sold") })).length,
      totalOrders: allOrders.length,
      pendingPayments: allOrders.filter((o) => o.status === "payment_verification").length,
      pendingDeals: allOrders.filter((o) => ["payment_verified", "delivered", "disputed"].includes(o.status)).length,
      completedOrders: completed.length,
      openDisputes: allOrders.filter((o) => o.status === "disputed").length,
      totalPayments: toRupees(
        allOrders
          .filter((o) => ["payment_verified", "delivered", "completed", "disputed"].includes(o.status))
          .reduce((s, o) => s + toPaise(o.price), 0),
      ),
      platformRevenue: toRupees(revenue),
      pendingWithdrawals: pendingWithdrawals.length,
      recentOrders: allOrders
        .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
        .slice(0, 8),
    };
  }),

  auditLogs: adminQuery.query(async () => {
    return getDb().query.auditLogs.findMany({
      orderBy: [desc(auditLogs.createdAt)],
      limit: 100,
    });
  }),

  credentialAccessLogs: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.query.credentialAccessLogs.findMany({
      orderBy: [desc(credentialAccessLogs.createdAt)],
      limit: 100,
    });
    return Promise.all(
      rows.map(async (r) => {
        const admin = await db.query.users.findFirst({ where: eq(users.id, r.adminId) });
        return { ...r, adminName: admin?.name ?? "admin" };
      }),
    );
  }),

  // ---------- Users ----------
  users: adminQuery
    .input(z.object({ q: z.string().trim().max(120).optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      let rows = await db.query.users.findMany({ orderBy: [desc(users.createdAt)], limit: 300 });
      if (input?.q) {
        const q = input.q.toLowerCase();
        rows = rows.filter(
          (u) =>
            u.name?.toLowerCase().includes(q) ||
            u.email?.toLowerCase().includes(q) ||
            String(u.id) === q,
        );
      }
      return rows.map(({ passwordHash: _drop, ...u }) => u);
    }),

  setUserStatus: adminQuery
    .input(z.object({ userId: z.number().int().positive(), status: z.enum(["active", "suspended", "banned"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const target = await db.query.users.findFirst({ where: eq(users.id, input.userId) });
      if (!target) throw new TRPCError({ code: "NOT_FOUND" });
      if (target.role === "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Cannot modify an admin account." });
      const prev = target.status;
      await db.update(users).set({ status: input.status }).where(eq(users.id, input.userId));
      await audit(ctx.user.id, `user.${input.status}`, "user", input.userId, `${target.email ?? target.name} — status: ${prev} → ${input.status}`);
      await notify(input.userId, `Account ${input.status}`, `Your account status was changed to ${input.status} by the marketplace team.`);
      return { ok: true };
    }),

  setUserRole: adminQuery
    .input(z.object({ userId: z.number().int().positive(), role: z.enum(["user", "admin"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const target = await db.query.users.findFirst({ where: eq(users.id, input.userId) });
      if (!target) throw new TRPCError({ code: "NOT_FOUND" });
      if (target.id === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot change your own role." });
      const prev = target.role;
      await db.update(users).set({ role: input.role }).where(eq(users.id, input.userId));
      await audit(ctx.user.id, "user.role", "user", input.userId, `${target.email ?? target.name} — role: ${prev} → ${input.role}`);
      await notify(input.userId, "Account role updated", `Your account role was changed to ${input.role} by the marketplace team.`);
      return { ok: true };
    }),

  deleteUser: adminQuery
    .input(z.object({ userId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const target = await db.query.users.findFirst({ where: eq(users.id, input.userId) });
      if (!target) throw new TRPCError({ code: "NOT_FOUND" });
      if (target.role === "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Cannot delete an admin account." });
      if (target.id === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot delete your own account." });
      // Keep orders/messages intact for records; remove the account and its marketplace presence.
      await db.update(listings).set({ status: "removed" }).where(eq(listings.sellerId, input.userId));
      await db.delete(withdrawals).where(eq(withdrawals.userId, input.userId));
      await db.delete(wallets).where(eq(wallets.userId, input.userId));
      await db.delete(users).where(eq(users.id, input.userId));
      await audit(ctx.user.id, "user.delete", "user", input.userId, `${target.email ?? target.name} — account and listings removed`);
      return { ok: true };
    }),

  userDetail: adminQuery
    .input(z.object({ userId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = getDb();
      const u = await db.query.users.findFirst({ where: eq(users.id, input.userId) });
      if (!u) throw new TRPCError({ code: "NOT_FOUND" });
      const { passwordHash: _drop, ...safeUser } = u;
      const userListings = await db.query.listings.findMany({
        where: eq(listings.sellerId, input.userId),
        orderBy: [desc(listings.createdAt)],
        limit: 50,
      });
      const userOrders = await db.query.orders.findMany({
        where: or(eq(orders.buyerId, input.userId), eq(orders.sellerId, input.userId)),
        orderBy: [desc(orders.createdAt)],
        limit: 50,
      });
      const wallet = await db.query.wallets.findFirst({ where: eq(wallets.userId, input.userId) });
      const txns = await db.query.walletTransactions.findMany({
        where: eq(walletTransactions.userId, input.userId),
        orderBy: [desc(walletTransactions.createdAt)],
        limit: 50,
      });
      return {
        user: safeUser,
        listings: userListings.map((l) => {
          const { deliveryCredentialsEnc: _c, ...rest } = l;
          return { ...rest, screenshots: undefined };
        }),
        orders: userOrders,
        wallet: wallet ?? null,
        transactions: txns,
      };
    }),

  setUserVerified: adminQuery
    .input(z.object({ userId: z.number().int().positive(), verified: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(users).set({ isVerified: input.verified }).where(eq(users.id, input.userId));
      await audit(ctx.user.id, input.verified ? "user.verify" : "user.unverify", "user", input.userId);
      return { ok: true };
    }),

  userOrders: adminQuery
    .input(z.object({ userId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.orders.findMany({
        where: or(eq(orders.buyerId, input.userId), eq(orders.sellerId, input.userId)),
        orderBy: [desc(orders.createdAt)],
        limit: 100,
      });
    }),

  // ---------- Games ----------
  saveGame: adminQuery
    .input(
      z.object({
        id: z.number().int().positive().optional(),
        name: z.string().trim().min(2).max(120),
        icon: z.string().max(600).optional(),
        description: z.string().max(500).optional(),
        status: z.enum(["active", "inactive"]).default("active"),
        sortOrder: z.number().int().default(0),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const slug = input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      if (input.id) {
        await db
          .update(games)
          .set({ name: input.name, icon: input.icon ?? null, description: input.description ?? null, status: input.status, sortOrder: input.sortOrder })
          .where(eq(games.id, input.id));
        await audit(ctx.user.id, "game.update", "game", input.id, input.name);
        return { id: input.id };
      }
      const [{ id }] = await db
        .insert(games)
        .values({ name: input.name, slug: `${slug}-${Date.now().toString(36)}`, icon: input.icon ?? null, description: input.description ?? null, status: input.status, sortOrder: input.sortOrder })
        .$returningId();
      await audit(ctx.user.id, "game.create", "game", id, input.name);
      return { id };
    }),

  deleteGame: adminQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(games).set({ status: "inactive" }).where(eq(games.id, input.id));
      await audit(ctx.user.id, "game.deactivate", "game", input.id);
      return { ok: true };
    }),

  allGames: adminQuery.query(async () => {
    return getDb().query.games.findMany({ orderBy: [games.sortOrder, games.name] });
  }),

  // ---------- Listings ----------
  allListings: adminQuery
    .input(z.object({ status: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      let rows = await db.query.listings.findMany({ orderBy: [desc(listings.createdAt)], limit: 300 });
      if (input?.status) rows = rows.filter((l) => l.status === input.status);
      const gameRows = await db.query.games.findMany();
      const gameMap = new Map(gameRows.map((g) => [g.id, g]));
      return Promise.all(
        rows.map(async (l) => {
          const seller = await db.query.users.findFirst({ where: eq(users.id, l.sellerId) });
          return {
            ...l,
            deliveryCredentialsEnc: undefined,
            hasCredentials: !!l.deliveryCredentialsEnc,
            screenshots: JSON.parse(l.screenshots ?? "[]") as string[],
            game: gameMap.get(l.gameId)?.name ?? "—",
            sellerName: seller?.name ?? "—",
          };
        }),
      );
    }),

  setListingStatus: adminQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        status: z.enum(["active", "rejected", "removed", "pending", "sold"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const l = await db.query.listings.findFirst({ where: eq(listings.id, input.id) });
      if (!l) throw new TRPCError({ code: "NOT_FOUND" });
      if (["active", "sold"].includes(input.status)) {
        const listingOrders = await db.query.orders.findMany({
          where: eq(orders.listingId, l.id),
        });
        if (listingOrders.some((o) => !["completed", "cancelled", "refunded"].includes(o.status))) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "This listing has an open order — resolve the order first." });
        }
      }
      const prev = l.status;
      await db.update(listings).set({ status: input.status }).where(eq(listings.id, input.id));
      await audit(ctx.user.id, `listing.${input.status}`, "listing", input.id, `"${l.title}" — status: ${prev} → ${input.status}`);
      await notify(l.sellerId, `Listing ${input.status}`, `"${l.title}" was ${input.status} by the marketplace team.`, "/seller?tab=listings");
      return { ok: true };
    }),

  updateListing: adminQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        title: z.string().trim().min(5).max(200),
        price: z.number().positive().max(10_000_000),
        description: z.string().trim().min(10).max(5000),
        accountLevel: z.string().trim().max(60).optional(),
        trophiesRank: z.string().trim().max(120).optional(),
        skinsItems: z.string().trim().max(2000).optional(),
        otherInfo: z.string().trim().max(2000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const l = await db.query.listings.findFirst({ where: eq(listings.id, input.id) });
      if (!l) throw new TRPCError({ code: "NOT_FOUND" });
      const { id, ...patch } = input;
      await db
        .update(listings)
        .set({ ...patch, price: input.price.toFixed(2) })
        .where(eq(listings.id, id));
      await audit(ctx.user.id, "listing.edit", "listing", id, `"${l.title}" — price: ${l.price} → ${input.price.toFixed(2)}, title → "${input.title}"`);
      return { ok: true };
    }),

  setListingFeatured: adminQuery
    .input(z.object({ id: z.number().int().positive(), featured: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(listings).set({ featured: input.featured }).where(eq(listings.id, input.id));
      await audit(ctx.user.id, input.featured ? "listing.feature" : "listing.unfeature", "listing", input.id);
      return { ok: true };
    }),

  // ---------- Orders ----------
  allOrders: adminQuery
    .input(z.object({ status: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      let rows = await db.query.orders.findMany({ orderBy: [desc(orders.createdAt)], limit: 300 });
      if (input?.status) rows = rows.filter((o) => o.status === input.status);
      return Promise.all(
        rows.map(async (o) => {
          const [l, buyer, seller] = await Promise.all([
            db.query.listings.findFirst({ where: eq(listings.id, o.listingId) }),
            db.query.users.findFirst({ where: eq(users.id, o.buyerId) }),
            db.query.users.findFirst({ where: eq(users.id, o.sellerId) }),
          ]);
          return { ...o, listingTitle: l?.title ?? "—", buyerName: buyer?.name ?? "—", sellerName: seller?.name ?? "—" };
        }),
      );
    }),

  verifyPayment: adminQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (o.status !== "payment_verification") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Order is not awaiting verification." });
      }
      await db
        .update(orders)
        .set({ status: "payment_verified", verifiedAt: new Date() })
        .where(eq(orders.id, o.id));
      await db.insert(messages).values({
        orderId: o.id,
        senderId: null,
        body: "Payment verified by GameBazaar. The private deal room is now open — seller, please deliver the account here.",
        isSystem: true,
      });
      await notify(o.buyerId, "Payment verified", `Order ${o.orderNo} — deal room is open.`, `/orders/${o.id}`);
      await notify(o.sellerId, "Payment verified", `Order ${o.orderNo} — please deliver the account in the deal room.`, `/orders/${o.id}`);
      await audit(ctx.user.id, "payment.verify", "order", o.id, o.orderNo);
      return { ok: true };
    }),

  rejectPayment: adminQuery
    .input(z.object({ orderId: z.number().int().positive(), reason: z.string().trim().min(3).max(500) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (o.status !== "payment_verification") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Order is not awaiting verification." });
      }
      await db
        .update(orders)
        .set({ status: "payment_rejected", paymentRejectReason: input.reason })
        .where(eq(orders.id, o.id));
      await notify(o.buyerId, "Payment rejected", `Order ${o.orderNo}: ${input.reason}. Please resubmit proof.`, `/orders/${o.id}`);
      await audit(ctx.user.id, "payment.reject", "order", o.id, input.reason);
      return { ok: true };
    }),

  // Securely reveal automatic-delivery credentials for a specific order (logged)
  viewCredentials: adminQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (!["payment_verified", "delivered", "disputed", "completed"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Credentials unlock after payment verification." });
      }
      const l = await db.query.listings.findFirst({ where: eq(listings.id, o.listingId) });
      if (!l?.deliveryCredentialsEnc) throw new TRPCError({ code: "NOT_FOUND", message: "No stored credentials for this order." });
      await logCredentialAccess(ctx.user.id, o.id, l.id);
      return { credentials: decryptSecret(l.deliveryCredentialsEnc) };
    }),

  completeOrder: adminQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (!["payment_verified", "delivered", "disputed"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Cannot complete an order in ${o.status}.` });
      }
      await settleOrder(o.id);
      await audit(ctx.user.id, "order.complete", "order", o.id, o.orderNo);
      return { ok: true };
    }),

  cancelOrder: adminQuery
    .input(z.object({ orderId: z.number().int().positive(), reason: z.string().max(500).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (["completed", "refunded", "cancelled"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Order already finalized." });
      }
      await db.transaction(async (tx) => {
        await tx.update(orders).set({ status: "cancelled" }).where(eq(orders.id, o.id));
        await tx.update(listings).set({ status: "active" }).where(eq(listings.id, o.listingId));
        await tx.insert(messages).values({
          orderId: o.id,
          senderId: null,
          body: `Order cancelled by admin.${input.reason ? ` Reason: ${input.reason}` : ""}`,
          isSystem: true,
        });
      });
      await notify(o.buyerId, "Order cancelled", `Order ${o.orderNo} was cancelled by admin.`, `/orders/${o.id}`);
      await notify(o.sellerId, "Order cancelled", `Order ${o.orderNo} was cancelled by admin.`);
      await audit(ctx.user.id, "order.cancel", "order", o.id, input.reason);
      return { ok: true };
    }),

  refundOrder: adminQuery
    .input(z.object({ orderId: z.number().int().positive(), reason: z.string().max(500).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      if (["completed", "refunded", "cancelled"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Order already finalized." });
      }
      await db.transaction(async (tx) => {
        await tx.update(orders).set({ status: "refunded" }).where(eq(orders.id, o.id));
        await tx.update(listings).set({ status: "active" }).where(eq(listings.id, o.listingId));
        await tx.insert(messages).values({
          orderId: o.id,
          senderId: null,
          body: `Order refunded by admin.${input.reason ? ` Reason: ${input.reason}` : ""}`,
          isSystem: true,
        });
      });
      await notify(o.buyerId, "Order refunded", `Order ${o.orderNo} was refunded. Contact support for settlement.`, `/orders/${o.id}`);
      await notify(o.sellerId, "Order refunded", `Order ${o.orderNo} was refunded to the buyer.`);
      await audit(ctx.user.id, "order.refund", "order", o.id, input.reason);
      return { ok: true };
    }),

  // Manual status override — settle/release side effects are applied so the
  // database never ends in an inconsistent state.
  setOrderStatus: adminQuery
    .input(
      z.object({
        orderId: z.number().int().positive(),
        status: z.enum([
          "awaiting_payment",
          "payment_verification",
          "payment_rejected",
          "payment_verified",
          "delivered",
          "completed",
          "disputed",
          "cancelled",
          "refunded",
        ]),
        note: z.string().trim().max(500).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      const prev = o.status;
      if (prev === input.status) return { ok: true };
      if (["completed", "cancelled", "refunded"].includes(prev)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Order is finalized as ${prev} and cannot be reopened.` });
      }
      if (input.status === "completed") {
        // Goes through the real settlement path (fee calc + seller credit)
        await settleOrder(o.id);
      } else {
        await db
          .update(orders)
          .set({
            status: input.status,
            verifiedAt: input.status === "payment_verified" ? new Date() : o.verifiedAt,
          })
          .where(eq(orders.id, o.id));
        if (["cancelled", "refunded"].includes(input.status)) {
          await db.update(listings).set({ status: "active" }).where(eq(listings.id, o.listingId));
        }
      }
      await db.insert(messages).values({
        orderId: o.id,
        senderId: null,
        body: `Order status changed by admin: ${prev} → ${input.status}.${input.note ? ` Note: ${input.note}` : ""}`,
        isSystem: true,
      });
      await notify(o.buyerId, "Order status updated", `Order ${o.orderNo}: ${prev} → ${input.status}.`, `/orders/${o.id}`);
      await notify(o.sellerId, "Order status updated", `Order ${o.orderNo}: ${prev} → ${input.status}.`, `/orders/${o.id}`);
      await audit(ctx.user.id, "order.status", "order", o.id, `${o.orderNo} — status: ${prev} → ${input.status}${input.note ? ` (${input.note})` : ""}`);
      return { ok: true };
    }),

  // ---------- Withdrawals ----------
  allWithdrawals: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.query.withdrawals.findMany({ orderBy: [desc(withdrawals.createdAt)], limit: 200 });
    return Promise.all(
      rows.map(async (w) => {
        const u = await db.query.users.findFirst({ where: eq(users.id, w.userId) });
        return { ...w, userName: u?.name ?? "—", userEmail: u?.email ?? "" };
      }),
    );
  }),

  processWithdrawal: adminQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        approve: z.boolean(),
        note: z.string().max(500).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const w = await db.query.withdrawals.findFirst({ where: eq(withdrawals.id, input.id) });
      if (!w) throw new TRPCError({ code: "NOT_FOUND" });
      if (w.status !== "pending") throw new TRPCError({ code: "BAD_REQUEST", message: "Already processed." });
      await db.transaction(async (tx) => {
        await tx
          .update(withdrawals)
          .set({ status: input.approve ? "approved" : "rejected", adminNote: input.note ?? null, processedAt: new Date() })
          .where(eq(withdrawals.id, w.id));
        if (!input.approve) {
          // Return funds to the seller's available balance
          const wal = await tx.query.wallets.findFirst({ where: eq(wallets.userId, w.userId) });
          const available = toPaise(wal?.availableBalance ?? "0");
          const back = toPaise(w.amount);
          await tx
            .update(wallets)
            .set({ availableBalance: toRupees(available + back) })
            .where(eq(wallets.userId, w.userId));
          await tx.insert(walletTransactions).values({
            userId: w.userId,
            type: "refund",
            amount: toRupees(back),
            balanceAfter: toRupees(available + back),
            note: `Withdrawal #${w.id} rejected — funds returned`,
          });
        }
      });
      await notify(
        w.userId,
        `Withdrawal ${input.approve ? "approved" : "rejected"}`,
        input.approve ? `₹${w.amount} withdrawal approved and being processed.` : `₹${w.amount} withdrawal rejected. Funds returned to your balance.`,
        "/seller?tab=wallet",
      );
      await audit(ctx.user.id, input.approve ? "withdrawal.approve" : "withdrawal.reject", "withdrawal", w.id, `₹${w.amount}`);
      return { ok: true };
    }),

  sellerBalances: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.query.wallets.findMany({ limit: 300 });
    return Promise.all(
      rows.map(async (w) => {
        const u = await db.query.users.findFirst({ where: eq(users.id, w.userId) });
        return { ...w, userName: u?.name ?? "—", userEmail: u?.email ?? "" };
      }),
    );
  }),

  // ---------- Disputes ----------
  allDisputes: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.query.disputes.findMany({ orderBy: [desc(disputes.createdAt)], limit: 200 });
    return Promise.all(
      rows.map(async (d) => {
        const o = await db.query.orders.findFirst({ where: eq(orders.id, d.orderId) });
        const opener = await db.query.users.findFirst({ where: eq(users.id, d.openedBy) });
        return { ...d, orderNo: o?.orderNo ?? "—", openerName: opener?.name ?? "—" };
      }),
    );
  }),

  resolveDispute: adminQuery
    .input(
      z.object({
        disputeId: z.number().int().positive(),
        resolution: z.enum(["refund", "complete", "cancel"]),
        note: z.string().trim().min(3).max(1000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const d = await db.query.disputes.findFirst({ where: eq(disputes.id, input.disputeId) });
      if (!d) throw new TRPCError({ code: "NOT_FOUND" });
      if (d.status === "resolved") throw new TRPCError({ code: "BAD_REQUEST", message: "Already resolved." });
      const o = await db.query.orders.findFirst({ where: eq(orders.id, d.orderId) });
      if (!o) throw new TRPCError({ code: "NOT_FOUND" });
      await db
        .update(disputes)
        .set({ status: "resolved", resolution: input.resolution, adminNote: input.note, resolvedAt: new Date() })
        .where(eq(disputes.id, d.id));
      if (input.resolution === "complete") {
        await settleOrder(o.id);
      } else {
        const finalStatus = input.resolution === "refund" ? "refunded" : "cancelled";
        await db.update(orders).set({ status: finalStatus }).where(eq(orders.id, o.id));
        await db.update(listings).set({ status: "active" }).where(eq(listings.id, o.listingId));
      }
      await db.insert(messages).values({
        orderId: o.id,
        senderId: null,
        body: `Dispute resolved by admin: ${input.resolution}. ${input.note}`,
        isSystem: true,
      });
      await notify(o.buyerId, "Dispute resolved", `Order ${o.orderNo}: ${input.resolution}. ${input.note}`, `/orders/${o.id}`);
      await notify(o.sellerId, "Dispute resolved", `Order ${o.orderNo}: ${input.resolution}. ${input.note}`, `/orders/${o.id}`);
      await audit(ctx.user.id, "dispute.resolve", "dispute", d.id, input.resolution);
      return { ok: true };
    }),

  // ---------- Settings ----------
  getSettings: adminQuery.query(async () => {
    const methods = await getPaymentMethods();
    return {
      platformFeePercent: await getSetting(SETTING_KEYS.platformFeePercent),
      minWithdrawal: await getSetting(SETTING_KEYS.minWithdrawal),
      listingAutoApprove: await getSetting(SETTING_KEYS.listingAutoApprove),
      listingsEnabled: await getSetting(SETTING_KEYS.listingsEnabled),
      withdrawalsEnabled: await getSetting(SETTING_KEYS.withdrawalsEnabled),
      marketplaceNotice: await getSetting(SETTING_KEYS.marketplaceNotice),
      paymentMethods: methods,
    };
  }),

  saveSettings: adminQuery
    .input(
      z.object({
        platformFeePercent: z.string().regex(/^\d+(\.\d{1,2})?$/).refine((v) => Number(v) >= 0 && Number(v) <= 50, "Fee must be 0-50%"),
        minWithdrawal: z.string().regex(/^\d+(\.\d{1,2})?$/),
        listingAutoApprove: z.enum(["true", "false"]),
        listingsEnabled: z.enum(["true", "false"]),
        withdrawalsEnabled: z.enum(["true", "false"]),
        marketplaceNotice: z.string().max(500),
        paymentMethods: z.object({
          upi: z.object({ enabled: z.boolean(), label: z.string().max(60), details: z.string().max(255) }),
          airtel: z.object({ enabled: z.boolean(), label: z.string().max(60), details: z.string().max(255) }),
          crypto: z.object({ enabled: z.boolean(), label: z.string().max(60), details: z.string().max(255), network: z.string().max(255).optional() }),
        }),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const prevFee = await getSetting(SETTING_KEYS.platformFeePercent);
      const prevMin = await getSetting(SETTING_KEYS.minWithdrawal);
      await setSetting(SETTING_KEYS.platformFeePercent, input.platformFeePercent);
      await setSetting(SETTING_KEYS.minWithdrawal, input.minWithdrawal);
      await setSetting(SETTING_KEYS.listingAutoApprove, input.listingAutoApprove);
      await setSetting(SETTING_KEYS.listingsEnabled, input.listingsEnabled);
      await setSetting(SETTING_KEYS.withdrawalsEnabled, input.withdrawalsEnabled);
      await setSetting(SETTING_KEYS.marketplaceNotice, input.marketplaceNotice);
      await setSetting(SETTING_KEYS.payUpi, JSON.stringify(input.paymentMethods.upi));
      await setSetting(SETTING_KEYS.payAirtel, JSON.stringify(input.paymentMethods.airtel));
      await setSetting(SETTING_KEYS.payCrypto, JSON.stringify(input.paymentMethods.crypto));
      await audit(
        ctx.user.id,
        "settings.update",
        "settings",
        "-",
        `fee: ${prevFee}% → ${input.platformFeePercent}%, minWithdrawal: ₹${prevMin} → ₹${input.minWithdrawal}, listings: ${input.listingsEnabled}, withdrawals: ${input.withdrawalsEnabled}, autoApprove: ${input.listingAutoApprove}`,
      );
      return { ok: true };
    }),
});
