import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { storage } from "./lib/storage";
import { rateLimit } from "./lib/ratelimit";

const MAX_BYTES = 5 * 1024 * 1024; // 5MB per image

export const storageRouter = createRouter({
  uploadImage: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(200),
        contentBase64: z.string(),
        contentType: z.string().regex(/^image\/(png|jpe?g|webp|gif)$/),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      rateLimit(`upload:${ctx.user.id}`, 30, 60_000);
      const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
      if (bytes.length > MAX_BYTES) {
        throw new Error("Image too large (max 5MB)");
      }
      const saved = await storage.uploadFile({
        fileContent: bytes,
        fileName: `u/${ctx.user.id}/${input.name}`,
        contentType: input.contentType,
      });
      return { key: saved.key, size: saved.size };
    }),

  // Presigned URLs are short-lived and keys are unguessable; needed to render
  // public listing screenshots as well as private order attachments.
  url: publicQuery
    .input(z.object({ key: z.string().min(1).max(600) }))
    .query(async ({ input }) => {
      const { url } = await storage.getPresignedUrl({ key: input.key });
      return { url };
    }),

  urls: publicQuery
    .input(z.object({ keys: z.array(z.string().min(1).max(600)).max(12) }))
    .query(async ({ input }) => {
      const { urls } = await storage.getPresignedUrls({ keys: input.keys });
      return { urls };
    }),
});
