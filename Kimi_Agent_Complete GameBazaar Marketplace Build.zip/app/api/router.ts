import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { storageRouter } from "./storage-router";
import { marketplaceRouter } from "./marketplace-router";
import { sellerRouter } from "./seller-router";
import { orderRouter } from "./order-router";
import { adminRouter } from "./admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  storage: storageRouter,
  market: marketplaceRouter,
  seller: sellerRouter,
  order: orderRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
