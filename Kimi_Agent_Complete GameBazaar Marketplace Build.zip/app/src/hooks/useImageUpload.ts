import { useState } from "react";
import { trpc } from "@/providers/trpc";

// Upload helper — converts a File to base64 and uploads through the backend
export function useImageUpload() {
  const [uploading, setUploading] = useState(false);
  const upload = trpc.storage.uploadImage.useMutation();

  const uploadFile = async (file: File): Promise<string> => {
    setUploading(true);
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(",")[1]);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const safeName = file.name.replace(/[^\w.\- ]+/g, "_").slice(-80);
      const res = await upload.mutateAsync({
        name: `${Date.now()}-${safeName}`,
        contentBase64: base64,
        contentType: file.type,
      });
      return res.key;
    } finally {
      setUploading(false);
    }
  };

  return { uploadFile, uploading };
}
