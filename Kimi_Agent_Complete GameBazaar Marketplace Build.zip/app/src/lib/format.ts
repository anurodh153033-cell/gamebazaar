export function inr(amount: string | number | null | undefined): string {
  const n = Number(amount ?? 0);
  return `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const ORDER_STATUS: Record<string, { label: string; color: string }> = {
  awaiting_payment: { label: "Awaiting Payment", color: "text-yellow-400" },
  payment_verification: { label: "Payment Verification", color: "text-amber-400" },
  payment_rejected: { label: "Payment Rejected", color: "text-red-400" },
  payment_verified: { label: "Payment Verified", color: "text-sky-400" },
  delivered: { label: "Delivered", color: "text-violet-400" },
  completed: { label: "Completed", color: "text-lime-400" },
  disputed: { label: "Disputed", color: "text-orange-400" },
  cancelled: { label: "Cancelled", color: "text-zinc-500" },
  refunded: { label: "Refunded", color: "text-zinc-400" },
};

export const LISTING_STATUS: Record<string, { label: string; color: string }> = {
  pending: { label: "Pending Review", color: "text-amber-400" },
  active: { label: "Active", color: "text-lime-400" },
  reserved: { label: "Reserved", color: "text-sky-400" },
  sold: { label: "Sold", color: "text-violet-400" },
  rejected: { label: "Rejected", color: "text-red-400" },
  removed: { label: "Removed", color: "text-zinc-500" },
};

export function timeAgo(d: Date | string): string {
  const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
