import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";

// Renders an image stored in platform object storage by its key.
export function StorageImage({
  storageKey,
  alt,
  className,
}: {
  storageKey: string | null | undefined;
  alt: string;
  className?: string;
}) {
  const { data } = trpc.storage.url.useQuery(
    { key: storageKey ?? "" },
    { enabled: !!storageKey, staleTime: 8 * 60_000, retry: false },
  );
  if (!storageKey || !data?.url) {
    return (
      <div className={cn("flex items-center justify-center bg-secondary text-muted-foreground", className)}>
        <GamepadGlyph />
      </div>
    );
  }
  return <img src={data.url} alt={alt} className={cn("object-cover", className)} loading="lazy" />;
}

export function GamepadGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={cn("h-8 w-8 opacity-40", className)}>
      <path d="M6 9h4M8 7v4M15 8h.01M17.5 10h.01M17 5H7a5 5 0 0 0-5 5v2a5 5 0 0 0 5 5c1.5 0 2.5-1 3.5-2h3c1 1 2 2 3.5 2a5 5 0 0 0 5-5v-2a5 5 0 0 0-5-5Z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
