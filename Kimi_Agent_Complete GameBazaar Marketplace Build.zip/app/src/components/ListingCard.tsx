import { Link } from "react-router";
import { Star, Zap, Handshake } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StorageImage } from "@/components/StorageImage";
import { inr } from "@/lib/format";

export type ListingCardData = {
  id: number;
  title: string;
  price: string;
  accountLevel: string | null;
  trophiesRank: string | null;
  deliveryMethod: string;
  screenshots: string[];
  game?: { name: string } | null;
  seller?: { name: string; avgRating: number | null; totalReviews: number; isVerified: boolean } | null;
};

export function ListingCard({ l }: { l: ListingCardData }) {
  return (
    <Card className="group overflow-hidden border-border bg-card transition-all hover:border-primary/50 hover:shadow-[0_0_30px_-12px_hsl(71_100%_50%/0.35)]">
      <Link to={`/listing/${l.id}`}>
        <div className="relative aspect-[16/9] overflow-hidden bg-secondary">
          <StorageImage storageKey={l.screenshots[0]} alt={l.title} className="h-full w-full transition-transform duration-300 group-hover:scale-105" />
          <div className="absolute left-2 top-2 flex gap-1.5">
            {l.game?.name && <Badge variant="secondary" className="bg-background/80 backdrop-blur">{l.game.name}</Badge>}
          </div>
          <Badge
            className={`absolute right-2 top-2 ${l.deliveryMethod === "automatic" ? "bg-primary text-primary-foreground" : "bg-background/80"}`}
          >
            {l.deliveryMethod === "automatic" ? <><Zap className="mr-1 h-3 w-3" />Auto</> : <><Handshake className="mr-1 h-3 w-3" />Manual</>}
          </Badge>
        </div>
      </Link>
      <div className="space-y-2 p-4">
        <Link to={`/listing/${l.id}`} className="line-clamp-1 font-display font-semibold hover:text-primary">
          {l.title}
        </Link>
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
          {l.accountLevel && <span>Lvl {l.accountLevel}</span>}
          {l.trophiesRank && <span className="line-clamp-1">{l.trophiesRank}</span>}
        </div>
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="h-3.5 w-3.5 fill-primary text-primary" />
            {l.seller?.avgRating ? l.seller.avgRating.toFixed(1) : "New"}
            <span>({l.seller?.totalReviews ?? 0})</span>
          </span>
          <span className="line-clamp-1">{l.seller?.name}{l.seller?.isVerified && " ✓"}</span>
        </div>
        <div className="flex items-center justify-between pt-1">
          <span className="font-display text-lg font-bold text-primary">{inr(l.price)}</span>
          <Button size="sm" asChild className="font-semibold">
            <Link to={`/listing/${l.id}`}>Buy Now</Link>
          </Button>
        </div>
      </div>
    </Card>
  );
}
