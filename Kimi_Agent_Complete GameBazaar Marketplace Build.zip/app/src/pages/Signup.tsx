import { Link, useNavigate } from "react-router";
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gamepad2, Store, ShoppingBag } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Signup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [accountType, setAccountType] = useState<"buyer" | "seller" | "both">("both");
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const signup = trpc.localAuth.signup.useMutation({
    onSuccess: async () => {
      await utils.invalidate();
      navigate("/");
    },
  });

  return (
    <Layout>
      <div className="mx-auto flex max-w-md flex-col items-center px-4 py-16">
        <Card className="w-full border-border bg-card">
          <CardHeader className="items-center text-center">
            <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-primary lime-glow">
              <Gamepad2 className="h-6 w-6 text-primary-foreground" />
            </div>
            <CardTitle className="font-display text-2xl">Create your account</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                signup.mutate({ name, email, password, accountType });
              }}
            >
              <div className="space-y-1.5">
                <Label>Display name</Label>
                <Input required minLength={2} value={name} onChange={(e) => setName(e.target.value)} placeholder="ProGamer_99" />
              </div>
              <div className="space-y-1.5">
                <Label>Email</Label>
                <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" />
              </div>
              <div className="space-y-1.5">
                <Label>Password</Label>
                <Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min. 8 characters" autoComplete="new-password" />
              </div>
              <div className="space-y-1.5">
                <Label>I want to</Label>
                <div className="grid grid-cols-3 gap-2">
                  {([
                    { v: "buyer", icon: ShoppingBag, l: "Buy" },
                    { v: "seller", icon: Store, l: "Sell" },
                    { v: "both", icon: Gamepad2, l: "Both" },
                  ] as const).map((o) => (
                    <button
                      key={o.v}
                      type="button"
                      onClick={() => setAccountType(o.v)}
                      className={cn(
                        "flex flex-col items-center gap-1 rounded-lg border p-3 text-sm transition-colors",
                        accountType === o.v ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/40",
                      )}
                    >
                      <o.icon className="h-5 w-5" />
                      {o.l}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">You can switch between buying and selling anytime.</p>
              </div>
              {signup.error && <p className="text-sm text-destructive">{signup.error.message}</p>}
              <Button type="submit" className="w-full font-semibold" size="lg" disabled={signup.isPending}>
                {signup.isPending ? "Creating…" : "Create account"}
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                Already have an account? <Link to="/login" className="text-primary hover:underline">Log in</Link>
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
