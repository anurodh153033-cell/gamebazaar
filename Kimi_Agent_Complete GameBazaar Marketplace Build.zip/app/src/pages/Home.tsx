import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Search, ShieldCheck, Zap, MessagesSquare, Gamepad2, TrendingUp, Sparkles, ArrowRight } from "lucide-react";
import { Layout } from "@/components/Layout";
import { ListingCard } from "@/components/ListingCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/providers/trpc";

const GAME_EMOJI: Record<string, string> = {
  "brawl-stars": "⭐",
  "clash-of-clans": "🏰",
  "clash-royale": "👑",
  "pubg-mobile": "🔫",
  bgmi: "🪂",
  fortnite: "🌪️",
  roblox: "🧱",
  "free-fire": "🔥",
  "genshin-impact": "⚔️",
  "call-of-duty-mobile": "🎯",
};

function HeroSearch() {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  return (
    <form
      className="mx-auto flex w-full max-w-2xl gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        navigate(q.trim() ? `/browse?q=${encodeURIComponent(q.trim())}` : "/browse");
      }}
    >
      <div className="relative flex-1">
        <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search Brawl Stars, Clash of Clans, PUBG accounts…"
          className="h-13 rounded-xl border-white/15 bg-secondary/70 py-6 pl-12 text-base"
        />
      </div>
      <Button type="submit" size="lg" className="lime-glow rounded-xl px-6 font-display font-bold">
        Search
      </Button>
    </form>
  );
}

export default function Home() {
  const { data, isLoading } = trpc.market.home.useQuery();

  return (
    <Layout>
      {/* Hero */}
      <section className="grid-bg relative overflow-hidden border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-16 text-center md:py-24">
          <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-primary">
            <ShieldCheck className="h-3.5 w-3.5" /> Escrow-protected trades · Admin-verified payments
          </div>
          <h1 className="font-display text-4xl font-bold leading-tight tracking-tight md:text-6xl">
            Buy &amp; Sell Game Accounts
            <br />
            <span className="text-glow text-primary">Trade with confidence.</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground md:text-lg">
            GameBazaar is the secure marketplace for game accounts — verified sellers, private deal rooms, and funds released only after you confirm delivery.
          </p>
          <div className="mt-8">
            <HeroSearch />
          </div>
          <div className="mx-auto mt-10 grid max-w-3xl grid-cols-1 gap-3 sm:grid-cols-3">
            {[
              { icon: ShieldCheck, title: "Escrow Payments", desc: "Admin verifies every payment before delivery starts" },
              { icon: MessagesSquare, title: "Private Deal Room", desc: "Buyer, seller & admin in one secure chat per order" },
              { icon: Zap, title: "Auto Delivery", desc: "Instant-delivery listings with encrypted credentials" },
            ].map((f) => (
              <Card key={f.title} className="glass p-4 text-left">
                <f.icon className="mb-2 h-5 w-5 text-primary" />
                <p className="font-display text-sm font-semibold">{f.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{f.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {data?.notice && (
        <div className="border-b border-primary/20 bg-primary/5 px-4 py-2.5 text-center text-sm text-primary">
          {data.notice}
        </div>
      )}

      {/* Popular games */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
            <Gamepad2 className="h-6 w-6 text-primary" /> Popular Games
          </h2>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/browse">View all <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {data?.games.map((g) => (
            <Link
              key={g.id}
              to={`/browse?game=${g.id}`}
              className="glass group rounded-xl p-4 text-center transition-all hover:border-primary/40 hover:bg-primary/5"
            >
              <div className="mb-2 text-3xl">{GAME_EMOJI[g.slug] ?? "🎮"}</div>
              <p className="line-clamp-1 font-display text-sm font-semibold group-hover:text-primary">{g.name}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">{(g as { activeListings?: number }).activeListings ?? 0} listings</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      {(data?.featured.length ?? 0) > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-12">
          <h2 className="mb-6 flex items-center gap-2 font-display text-2xl font-bold">
            <Sparkles className="h-6 w-6 text-primary" /> Featured Listings
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {data!.featured.map((l) => (
              <ListingCard key={l.id} l={l} />
            ))}
          </div>
        </section>
      )}

      {/* Latest */}
      <section className="mx-auto max-w-7xl px-4 pb-16">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
            <TrendingUp className="h-6 w-6 text-primary" /> Latest Listings
          </h2>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/browse">Browse all <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-72 animate-pulse rounded-xl bg-secondary/50" />
            ))}
          </div>
        ) : data?.latest.length ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {data.latest.map((l) => (
              <ListingCard key={l.id} l={l} />
            ))}
          </div>
        ) : (
          <Card className="glass p-10 text-center">
            <Gamepad2 className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="font-display font-semibold">No listings yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Be the first to sell an account on GameBazaar.</p>
            <Button asChild className="lime-glow mt-4 font-semibold">
              <Link to="/seller?tab=new">Create a listing</Link>
            </Button>
          </Card>
        )}
      </section>
    </Layout>
  );
}
