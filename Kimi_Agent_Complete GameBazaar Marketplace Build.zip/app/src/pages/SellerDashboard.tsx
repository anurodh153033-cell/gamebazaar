import { Link, useSearchParams } from "react-router";
import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useImageUpload } from "@/hooks/useImageUpload";
import { fmtDate, inr, LISTING_STATUS, ORDER_STATUS } from "@/lib/format";
import { Plus, Trash2, Upload, Wallet as WalletIcon, X, ShieldAlert } from "lucide-react";
import { StorageImage } from "@/components/StorageImage";

type ListingForm = {
  gameId: number | null;
  title: string;
  price: string;
  description: string;
  accountLevel: string;
  trophiesRank: string;
  skinsItems: string;
  screenshots: string[];
  otherInfo: string;
  deliveryMethod: "manual" | "automatic";
  deliveryCredentials: string;
};

const EMPTY: ListingForm = {
  gameId: null, title: "", price: "", description: "", accountLevel: "",
  trophiesRank: "", skinsItems: "", screenshots: [], otherInfo: "",
  deliveryMethod: "manual", deliveryCredentials: "",
};

function ListingEditor({ editId, onDone }: { editId: number | null; onDone: () => void }) {
  const { data: games } = trpc.market.games.useQuery();
  const { data: mine } = trpc.seller.myListings.useQuery();
  const utils = trpc.useUtils();
  const { uploadFile, uploading } = useImageUpload();
  const [form, setForm] = useState<ListingForm>(EMPTY);
  const [loadedFor, setLoadedFor] = useState<number | null>(null);

  useEffect(() => {
    if (editId && mine && loadedFor !== editId) {
      const l = mine.find((x) => x.id === editId);
      if (l) {
        setForm({
          gameId: l.gameId, title: l.title, price: String(l.price), description: l.description ?? "",
          accountLevel: l.accountLevel ?? "", trophiesRank: l.trophiesRank ?? "", skinsItems: l.skinsItems ?? "",
          screenshots: l.screenshots, otherInfo: l.otherInfo ?? "", deliveryMethod: l.deliveryMethod,
          deliveryCredentials: "",
        });
        setLoadedFor(editId);
      }
    }
    if (!editId && loadedFor !== null) { setForm(EMPTY); setLoadedFor(null); }
  }, [editId, mine, loadedFor]);

  const create = trpc.seller.createListing.useMutation({ onSuccess: () => { utils.seller.myListings.invalidate(); onDone(); } });
  const update = trpc.seller.updateListing.useMutation({ onSuccess: () => { utils.seller.myListings.invalidate(); onDone(); } });
  const busy = create.isPending || update.isPending;
  const err = create.error ?? update.error;
  const locked = editId != null && mine?.find((x) => x.id === editId)?.status === "reserved";

  const set = <K extends keyof ListingForm>(k: K, v: ListingForm[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    const payload = {
      gameId: form.gameId!, title: form.title, price: Number(form.price), description: form.description,
      accountLevel: form.accountLevel || undefined, trophiesRank: form.trophiesRank || undefined,
      skinsItems: form.skinsItems || undefined, screenshots: form.screenshots,
      otherInfo: form.otherInfo || undefined, deliveryMethod: form.deliveryMethod,
      deliveryCredentials: form.deliveryCredentials || undefined,
    };
    if (editId) update.mutate({ id: editId, ...payload });
    else create.mutate(payload);
  };

  return (
    <div className="space-y-4">
      {locked && (
        <p className="rounded-lg border border-sky-500/40 bg-sky-500/10 p-3 text-sm text-sky-300">
          This listing is locked by an active order — you can only update the delivery credentials.
        </p>
      )}
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Game *</Label>
          <Select disabled={locked} value={form.gameId ? String(form.gameId) : ""} onValueChange={(v) => set("gameId", Number(v))}>
            <SelectTrigger><SelectValue placeholder="Select a game" /></SelectTrigger>
            <SelectContent>{games?.map((g) => <SelectItem key={g.id} value={String(g.id)}>{g.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Price (₹) *</Label>
          <Input disabled={locked} type="number" min={1} value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="999" />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Listing title *</Label>
        <Input disabled={locked} value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Maxed Brawl Stars account — 60k trophies" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Account level</Label>
          <Input disabled={locked} value={form.accountLevel} onChange={(e) => set("accountLevel", e.target.value)} placeholder="e.g. 145" />
        </div>
        <div className="space-y-1.5">
          <Label>Trophies / Rank</Label>
          <Input disabled={locked} value={form.trophiesRank} onChange={(e) => set("trophiesRank", e.target.value)} placeholder="e.g. 60,000 trophies / Conqueror" />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Description *</Label>
        <Textarea disabled={locked} rows={4} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Full account details, what's included, login method…" />
      </div>
      <div className="space-y-1.5">
        <Label>Skins / items</Label>
        <Textarea disabled={locked} rows={2} value={form.skinsItems} onChange={(e) => set("skinsItems", e.target.value)} placeholder="Legendary skins, rare items, BP rewards…" />
      </div>
      <div className="space-y-1.5">
        <Label>Screenshots (up to 8)</Label>
        <div className="flex flex-wrap gap-2">
          {form.screenshots.map((s, i) => (
            <div key={s} className="relative h-20 w-32 overflow-hidden rounded-lg border border-border">
              <StorageImage storageKey={s} alt="" className="h-full w-full" />
              <button className="absolute right-1 top-1 rounded-full bg-background/80 p-0.5" onClick={() => set("screenshots", form.screenshots.filter((_, j) => j !== i))}>
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
          {form.screenshots.length < 8 && (
            <label className="flex h-20 w-32 cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-border text-xs text-muted-foreground hover:border-primary/40">
              {uploading ? "…" : <><Upload className="h-4 w-4" />Upload</>}
              <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) set("screenshots", [...form.screenshots, await uploadFile(f)]); }} />
            </label>
          )}
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Other account information</Label>
        <Textarea disabled={locked} rows={2} value={form.otherInfo} onChange={(e) => set("otherInfo", e.target.value)} placeholder="Region, linked email changeable, etc." />
      </div>
      <div className="space-y-2">
        <Label>Delivery method *</Label>
        <RadioGroup disabled={locked} value={form.deliveryMethod} onValueChange={(v) => set("deliveryMethod", v as "manual" | "automatic")} className="grid gap-2 md:grid-cols-2">
          <Label htmlFor="dm-manual" className={`flex cursor-pointer items-start gap-3 rounded-lg border p-4 ${form.deliveryMethod === "manual" ? "border-primary bg-primary/10" : "border-border"}`}>
            <RadioGroupItem value="manual" id="dm-manual" className="mt-1" />
            <span><span className="font-medium">Manual delivery</span><span className="block text-xs text-muted-foreground">You deliver the account yourself in the private deal room after payment is verified.</span></span>
          </Label>
          <Label htmlFor="dm-auto" className={`flex cursor-pointer items-start gap-3 rounded-lg border p-4 ${form.deliveryMethod === "automatic" ? "border-primary bg-primary/10" : "border-border"}`}>
            <RadioGroupItem value="automatic" id="dm-auto" className="mt-1" />
            <span><span className="font-medium">⚡ Automatic delivery</span><span className="block text-xs text-muted-foreground">Store the account credentials encrypted. Admin releases them to the buyer after verified payment.</span></span>
          </Label>
        </RadioGroup>
      </div>
      {form.deliveryMethod === "automatic" && (
        <div className="space-y-1.5">
          <Label>Delivery credentials (encrypted at rest, never public)</Label>
          <Textarea rows={3} value={form.deliveryCredentials} onChange={(e) => set("deliveryCredentials", e.target.value)} placeholder={editId ? "Leave empty to keep existing credentials" : "Login email/username + password + any 2FA backup info"} />
          <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
            Only for accounts that are legally transferable under the game's terms. Credentials are AES-256 encrypted and only accessible to admins handling the order (all access is logged).
          </p>
        </div>
      )}
      {err && <p className="text-sm text-destructive">{err.message}</p>}
      <Button className="font-semibold" disabled={busy || !form.gameId || form.title.trim().length < 5 || !form.description || !form.price || Number(form.price) <= 0} onClick={submit}>
        {busy ? "Saving…" : editId ? "Save changes" : "Publish listing"}
      </Button>
    </div>
  );
}

export default function SellerDashboard() {
  const { user } = useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "overview";
  const [editId, setEditId] = useState<number | null>(params.get("edit") ? Number(params.get("edit")) : null);
  const utils = trpc.useUtils();

  const { data: earnings } = trpc.seller.earnings.useQuery();
  const { data: mine, isLoading } = trpc.seller.myListings.useQuery();
  const { data: sales } = trpc.seller.mySales.useQuery();
  const { data: wallet } = trpc.seller.wallet.useQuery();
  const { data: txns } = trpc.seller.transactions.useQuery();
  const { data: wds } = trpc.seller.myWithdrawals.useQuery();

  const [wdAmount, setWdAmount] = useState("");
  const [wdMethod, setWdMethod] = useState<"upi" | "airtel" | "crypto">("upi");
  const [wdDest, setWdDest] = useState("");

  const del = trpc.seller.deleteListing.useMutation({ onSuccess: () => utils.seller.myListings.invalidate() });
  const removeCreds = trpc.seller.removeCredentials.useMutation({ onSuccess: () => utils.seller.myListings.invalidate() });
  const requestWd = trpc.seller.requestWithdrawal.useMutation({
    onSuccess: () => {
      setWdAmount(""); setWdDest("");
      utils.seller.wallet.invalidate();
      utils.seller.myWithdrawals.invalidate();
      utils.seller.transactions.invalidate();
    },
  });

  const goTab = (t: string) => { setParams({ tab: t }); if (t !== "new") setEditId(null); };
  const canSell = ["seller", "both"].includes(user?.accountType ?? "");

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="font-display text-2xl font-bold">Seller dashboard</h1>
        {!canSell && (
          <p className="mt-4 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 text-sm">
            Your account is in buyer-only mode. <Link to="/profile" className="text-primary underline">Enable selling in your profile</Link> to create listings.
          </p>
        )}
        <Tabs value={tab} onValueChange={goTab} className="mt-6">
          <TabsList className="flex w-full flex-wrap justify-start">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="listings">Listings</TabsTrigger>
            <TabsTrigger value="new"><Plus className="mr-1 h-3.5 w-3.5" />New listing</TabsTrigger>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="wallet">Wallet</TabsTrigger>
            <TabsTrigger value="txns">Transactions</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {[
                { label: "Available balance", value: inr(earnings?.wallet.availableBalance) },
                { label: "Total earnings", value: inr(earnings?.totalEarnings) },
                { label: "Completed sales", value: String(earnings?.completedCount ?? 0) },
                { label: "Pending deliveries", value: String(earnings?.pendingDeliveryCount ?? 0) },
              ].map((s) => (
                <Card key={s.label} className="border-border bg-card"><CardContent className="p-5">
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className="mt-1 font-display text-2xl font-bold text-primary">{s.value}</p>
                </CardContent></Card>
              ))}
            </div>
            <h2 className="mt-8 font-display text-lg font-semibold">Pending orders</h2>
            <div className="mt-3 space-y-2">
              {sales?.filter((o) => ["payment_verified", "delivered", "payment_verification"].includes(o.status)).map((o) => (
                <Card key={o.id} className="border-border bg-card"><CardContent className="flex flex-wrap items-center gap-3 p-4 text-sm">
                  <span className="font-medium">{o.orderNo}</span>
                  <span className="text-muted-foreground line-clamp-1">{o.listingTitle}</span>
                  <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                  <Button size="sm" className="ml-auto" asChild><Link to={`/orders/${o.id}`}>Open deal room</Link></Button>
                </CardContent></Card>
              ))}
              {sales && !sales.filter((o) => ["payment_verified", "delivered", "payment_verification"].includes(o.status)).length && (
                <p className="text-sm text-muted-foreground">No pending orders.</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="listings" className="mt-6">
            {isLoading && <Skeleton className="h-40 rounded-xl" />}
            <div className="grid gap-3">
              {mine?.map((l) => {
                const st = LISTING_STATUS[l.status];
                return (
                  <Card key={l.id} className="border-border bg-card">
                    <CardContent className="flex flex-wrap items-center gap-4 p-4">
                      <div className="min-w-0 flex-1">
                        <p className="line-clamp-1 font-medium">{l.title}</p>
                        <p className="text-xs text-muted-foreground">{l.game?.name} · {fmtDate(l.createdAt)} · {l.views} views</p>
                      </div>
                      <Badge variant="outline" className={st?.color}>{st?.label}</Badge>
                      <span className="font-display font-bold text-primary">{inr(l.price)}</span>
                      {l.deliveryMethod === "automatic" && (
                        <Badge variant="secondary">{l.hasCredentials ? "⚡ creds stored" : "⚠ no creds"}</Badge>
                      )}
                      <div className="flex gap-1.5">
                        <Button size="sm" variant="outline" onClick={() => { setEditId(l.id); setParams({ tab: "new", edit: String(l.id) }); }}>Edit</Button>
                        {l.deliveryMethod === "automatic" && l.hasCredentials && (
                          <Button size="sm" variant="outline" disabled={removeCreds.isPending} onClick={() => { if (confirm("Remove stored credentials?")) removeCreds.mutate({ id: l.id }); }}>
                            Remove creds
                          </Button>
                        )}
                        {!["reserved", "sold"].includes(l.status) && (
                          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm("Delete this listing?")) del.mutate({ id: l.id }); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
              {!isLoading && !mine?.length && <p className="text-sm text-muted-foreground">No listings yet — create your first one.</p>}
            </div>
          </TabsContent>

          <TabsContent value="new" className="mt-6">
            <Card className="border-border bg-card"><CardContent className="p-6">
              <ListingEditor editId={editId} onDone={() => { setEditId(null); goTab("listings"); }} />
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="sales" className="mt-6">
            <div className="space-y-2">
              {sales?.map((o) => (
                <Card key={o.id} className="border-border bg-card"><CardContent className="flex flex-wrap items-center gap-3 p-4 text-sm">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">{o.orderNo}</p>
                    <p className="text-xs text-muted-foreground line-clamp-1">{o.listingTitle} · buyer: {o.buyerName} · {fmtDate(o.createdAt)}</p>
                  </div>
                  <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                  <span className="font-medium">{inr(o.sellerAmount)}</span>
                  <Button size="sm" variant="outline" asChild><Link to={`/orders/${o.id}`}>Open</Link></Button>
                </CardContent></Card>
              ))}
              {!sales?.length && <p className="text-sm text-muted-foreground">No sales yet.</p>}
            </div>
          </TabsContent>

          <TabsContent value="wallet" className="mt-6">
            <div className="grid gap-4 lg:grid-cols-3">
              <Card className="border-border bg-card lg:col-span-1">
                <CardHeader><CardTitle className="flex items-center gap-2 text-base"><WalletIcon className="h-4 w-4 text-primary" /> Wallet</CardTitle></CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Available</span><span className="font-display text-xl font-bold text-primary">{inr(wallet?.availableBalance)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Total earnings</span><span>{inr(wallet?.totalEarnings)}</span></div>
                  <p className="text-xs text-muted-foreground">Minimum withdrawal: {inr(wallet?.minWithdrawal)}</p>
                  <div className="space-y-2 border-t border-border pt-3">
                    <Label>Amount (₹)</Label>
                    <Input type="number" value={wdAmount} onChange={(e) => setWdAmount(e.target.value)} />
                    <Label>Method</Label>
                    <Select value={wdMethod} onValueChange={(v) => setWdMethod(v as typeof wdMethod)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="upi">UPI</SelectItem>
                        <SelectItem value="airtel">Airtel Payment Bank</SelectItem>
                        <SelectItem value="crypto">Crypto</SelectItem>
                      </SelectContent>
                    </Select>
                    <Label>Destination</Label>
                    <Input value={wdDest} onChange={(e) => setWdDest(e.target.value)} placeholder={wdMethod === "crypto" ? "Wallet address" : "UPI ID / account"} />
                    {requestWd.error && <p className="text-sm text-destructive">{requestWd.error.message}</p>}
                    <Button className="w-full" disabled={requestWd.isPending || !wdAmount || wdDest.trim().length < 4} onClick={() => requestWd.mutate({ amount: Number(wdAmount), method: wdMethod, destination: wdDest.trim() })}>
                      {requestWd.isPending ? "Requesting…" : "Withdraw"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border bg-card lg:col-span-2">
                <CardHeader><CardTitle className="text-base">Withdrawal history</CardTitle></CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {wds?.map((w) => (
                    <div key={w.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3">
                      <span className="font-medium">{inr(w.amount)}</span>
                      <span className="text-xs text-muted-foreground">{w.method.toUpperCase()} → {w.destination}</span>
                      <Badge variant="outline" className={w.status === "approved" ? "text-primary" : w.status === "rejected" ? "text-destructive" : "text-amber-400"}>{w.status}</Badge>
                      <span className="ml-auto text-xs text-muted-foreground">{fmtDate(w.createdAt)}</span>
                      {w.adminNote && <span className="w-full text-xs text-muted-foreground">Admin: {w.adminNote}</span>}
                    </div>
                  ))}
                  {!wds?.length && <p className="text-muted-foreground">No withdrawals yet.</p>}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="txns" className="mt-6">
            <Card className="border-border bg-card">
              <CardContent className="space-y-2 p-4 text-sm">
                {txns?.map((t) => (
                  <div key={t.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3">
                    <Badge variant="secondary">{t.type.replace("_", " ")}</Badge>
                    <span className={Number(t.amount) >= 0 ? "font-medium text-primary" : "font-medium text-destructive"}>{inr(t.amount)}</span>
                    <span className="text-xs text-muted-foreground line-clamp-1">{t.note}</span>
                    <span className="ml-auto text-xs text-muted-foreground">Balance: {inr(t.balanceAfter)} · {fmtDate(t.createdAt)}</span>
                  </div>
                ))}
                {!txns?.length && <p className="text-muted-foreground">No transactions yet.</p>}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
