import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fmtDate } from "@/lib/format";
import { BadgeCheck } from "lucide-react";

export default function Profile() {
  const { user, refresh } = useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const [name, setName] = useState(user?.name ?? "");
  const [bio, setBio] = useState(user?.bio ?? "");
  const [accountType, setAccountType] = useState<"buyer" | "seller" | "both">(user?.accountType ?? "both");
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [saved, setSaved] = useState(false);

  const update = trpc.market.updateProfile.useMutation({
    onSuccess: async () => { await refresh(); setSaved(true); setTimeout(() => setSaved(false), 2000); },
  });
  const changePw = trpc.localAuth.changePassword.useMutation({
    onSuccess: () => { setCurrent(""); setNext(""); },
  });

  return (
    <Layout>
      <div className="mx-auto max-w-2xl px-4 py-8">
        <h1 className="font-display text-2xl font-bold">Profile</h1>
        <Card className="mt-6 border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              Account
              {user?.isVerified && <span className="flex items-center gap-1 text-xs text-primary"><BadgeCheck className="h-4 w-4" /> Verified</span>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-xs text-muted-foreground">Email</p><p>{user?.email ?? "— (Kimi account)"}</p></div>
              <div><p className="text-xs text-muted-foreground">Member since</p><p>{fmtDate(user?.createdAt)}</p></div>
            </div>
            <div className="space-y-1.5">
              <Label>Display name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Account mode</Label>
              <Select value={accountType} onValueChange={(v) => setAccountType(v as typeof accountType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="buyer">Buyer</SelectItem>
                  <SelectItem value="seller">Seller</SelectItem>
                  <SelectItem value="both">Buy & sell</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Switch between buying and selling anytime.</p>
            </div>
            <div className="space-y-1.5">
              <Label>Bio</Label>
              <Textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Tell buyers about yourself…" />
            </div>
            {update.error && <p className="text-sm text-destructive">{update.error.message}</p>}
            <Button disabled={update.isPending} onClick={() => update.mutate({ name, bio, accountType })}>
              {saved ? "Saved ✓" : update.isPending ? "Saving…" : "Save profile"}
            </Button>
          </CardContent>
        </Card>

        {user?.unionId?.startsWith("local:") && (
          <Card className="mt-4 border-border bg-card">
            <CardHeader><CardTitle className="text-base">Change password</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Current password</Label>
                <Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
              </div>
              <div className="space-y-1.5">
                <Label>New password</Label>
                <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
              </div>
              {changePw.error && <p className="text-sm text-destructive">{changePw.error.message}</p>}
              {changePw.isSuccess && <p className="text-sm text-primary">Password updated ✓</p>}
              <Button variant="outline" disabled={changePw.isPending || !current || next.length < 8} onClick={() => changePw.mutate({ current, password: next })}>
                Update password
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className="mt-4 border-border bg-card">
          <CardHeader><CardTitle className="text-base">Account verification</CardTitle></CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            {user?.isVerified
              ? "Your account is verified by the GameBazaar team. The badge appears next to your name on all listings."
              : "Verification is granted by the marketplace team to trusted sellers with successful completed trades."}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
