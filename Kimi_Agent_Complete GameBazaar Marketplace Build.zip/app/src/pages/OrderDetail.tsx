import { Link, useParams } from "react-router";
import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { StorageImage } from "@/components/StorageImage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useImageUpload } from "@/hooks/useImageUpload";
import { fmtDate, inr, ORDER_STATUS } from "@/lib/format";
import { Check, Paperclip, Send, ShieldCheck, Star, AlertTriangle, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = ["awaiting_payment", "payment_verification", "payment_verified", "delivered", "completed"];

export default function OrderDetail() {
  const { id } = useParams();
  const orderId = Number(id);
  const { user } = useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const { data, isLoading } = trpc.order.detail.useQuery({ id: orderId }, { enabled: !!orderId, refetchInterval: 6000 });
  const { data: msgs } = trpc.order.messages.useQuery({ orderId }, { enabled: !!orderId, refetchInterval: 4000 });
  const utils = trpc.useUtils();
  const { uploadFile, uploading } = useImageUpload();

  const [msg, setMsg] = useState("");
  const [attach, setAttach] = useState<string | null>(null);
  const [disputeReason, setDisputeReason] = useState("");
  const [disputeEvidence, setDisputeEvidence] = useState<string | null>(null);
  const [disputeResponse, setDisputeResponse] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [creds, setCreds] = useState<string | null>(null);
  const chatEnd = useRef<HTMLDivElement>(null);

  const invalidate = () => {
    utils.order.detail.invalidate({ id: orderId });
    utils.order.messages.invalidate({ orderId });
  };

  const send = trpc.order.sendMessage.useMutation({
    onSuccess: () => { setMsg(""); setAttach(null); utils.order.messages.invalidate({ orderId }); },
  });
  const confirm = trpc.order.confirmReceived.useMutation({ onSuccess: invalidate });
  const delivered = trpc.order.markDelivered.useMutation({ onSuccess: invalidate });
  const review = trpc.order.review.useMutation({ onSuccess: invalidate });
  const openDispute = trpc.order.openDispute.useMutation({
    onSuccess: () => { setDisputeReason(""); setDisputeEvidence(null); invalidate(); },
  });
  const respondDispute = trpc.order.respondDispute.useMutation({
    onSuccess: () => { setDisputeResponse(""); invalidate(); },
  });
  const viewCreds = trpc.admin.viewCredentials.useQuery({ orderId }, { enabled: false });

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs?.length]);

  if (isLoading || !data) return <Layout><div className="mx-auto max-w-5xl p-8"><Skeleton className="h-96 rounded-xl" /></div></Layout>;

  const o = data.order;
  const st = ORDER_STATUS[o.status] ?? { label: o.status, color: "" };
  const myRole = data.myRole;
  const stepIdx = o.status === "payment_rejected" ? 1 : STEPS.indexOf(o.status);
  const chatOpen = ["payment_verified", "delivered", "disputed", "completed"].includes(o.status);
  const d = data.dispute;

  return (
    <Layout>
      <div className="mx-auto max-w-6xl px-4 py-8">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold">{o.orderNo}</h1>
            <p className="text-sm text-muted-foreground">{data.listing?.title} · created {fmtDate(o.createdAt)}</p>
          </div>
          <span className={cn("rounded-full border border-border bg-card px-4 py-1.5 text-sm font-semibold", st.color)}>{st.label}</span>
        </div>

        {/* Progress */}
        {!["cancelled", "refunded", "disputed"].includes(o.status) && (
          <div className="mt-6 flex items-center">
            {["Payment", "Verification", "Deal room", "Delivery", "Completed"].map((label, i) => (
              <div key={label} className="flex flex-1 items-center last:flex-none">
                <div className="flex flex-col items-center">
                  <div className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full border text-xs font-bold",
                    i <= stepIdx ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground",
                  )}>
                    {i < stepIdx ? <Check className="h-4 w-4" /> : i + 1}
                  </div>
                  <span className="mt-1.5 hidden text-[10px] text-muted-foreground sm:block">{label}</span>
                </div>
                {i < 4 && <div className={cn("mx-1 mb-0 h-0.5 flex-1 sm:mb-4", i < stepIdx ? "bg-primary" : "bg-border")} />}
              </div>
            ))}
          </div>
        )}
        {o.status === "payment_rejected" && (
          <div className="mt-4 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm">
            <p className="font-semibold text-destructive">Payment rejected: {o.paymentRejectReason}</p>
            {myRole === "buyer" && <Button className="mt-3" size="sm" asChild><Link to={`/checkout/${o.id}`}>Resubmit payment</Link></Button>}
          </div>
        )}

        <div className="mt-8 grid gap-6 lg:grid-cols-5">
          {/* Left: order info */}
          <div className="space-y-4 lg:col-span-2">
            <Card className="border-border bg-card">
              <CardHeader><CardTitle className="text-base">Order details</CardTitle></CardHeader>
              <CardContent className="space-y-2 text-sm">
                <Row k="Item" v={data.listing?.title} link={`/listing/${data.listing?.id}`} />
                <Row k="Price" v={inr(o.price)} />
                <Row k={`Platform fee (${o.feePercent}%)`} v={inr(o.platformFee)} />
                <Row k="Seller receives" v={inr(o.sellerAmount)} />
                <Row k="Payment method" v={o.paymentMethod?.toUpperCase() ?? "—"} />
                <Row k="Transaction ref" v={o.transactionRef ?? "—"} mono />
                <Row k="Buyer" v={data.buyer?.name} />
                <Row k="Seller" v={data.seller?.name} />
                <Row k="Delivery" v={data.listing?.deliveryMethod === "automatic" ? "⚡ Automatic" : "Manual"} />
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 border-t border-border pt-2 text-xs text-muted-foreground">
                  <span>Created: {fmtDate(o.createdAt)}</span>
                  <span>Paid: {fmtDate(o.paidAt)}</span>
                  <span>Verified: {fmtDate(o.verifiedAt)}</span>
                  <span>Delivered: {fmtDate(o.deliveredAt)}</span>
                  <span>Completed: {fmtDate(o.completedAt)}</span>
                </div>
                {o.paymentProof && (
                  <div className="pt-2">
                    <p className="mb-1 text-xs text-muted-foreground">Payment proof</p>
                    <a href="#" onClick={(e) => e.preventDefault()}>
                      <StorageImage storageKey={o.paymentProof} alt="Payment proof" className="max-h-48 w-full rounded-lg border border-border object-contain" />
                    </a>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="border-border bg-card">
              <CardHeader><CardTitle className="text-base">Actions</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {myRole === "buyer" && ["payment_verified", "delivered"].includes(o.status) && (
                  <Button className="w-full lime-glow font-semibold" disabled={confirm.isPending} onClick={() => confirm.mutate({ orderId: o.id })}>
                    <Check className="mr-2 h-4 w-4" /> {confirm.isPending ? "Confirming…" : "Confirm Received"}
                  </Button>
                )}
                {myRole === "seller" && o.status === "payment_verified" && (
                  <Button className="w-full font-semibold" disabled={delivered.isPending} onClick={() => delivered.mutate({ orderId: o.id })}>
                    Mark as delivered
                  </Button>
                )}
                {myRole === "admin" && ["payment_verified", "delivered", "disputed", "completed"].includes(o.status) && data.listing?.deliveryMethod === "automatic" && (
                  <Button
                    variant="outline" className="w-full"
                    onClick={async () => {
                      const r = await viewCreds.refetch();
                      if (r.data) setCreds(r.data.credentials);
                    }}
                  >
                    <Eye className="mr-2 h-4 w-4" /> View stored credentials (logged)
                  </Button>
                )}
                {creds && (
                  <pre className="whitespace-pre-wrap rounded-lg border border-primary/30 bg-primary/10 p-3 font-mono text-xs text-primary">{creds}</pre>
                )}
                {confirm.error && <p className="text-sm text-destructive">{confirm.error.message}</p>}
                {delivered.error && <p className="text-sm text-destructive">{delivered.error.message}</p>}

                {/* Dispute */}
                {myRole !== "admin" && ["payment_verification", "payment_verified", "delivered", "disputed"].includes(o.status) && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full border-destructive/40 text-destructive">
                        <AlertTriangle className="mr-2 h-4 w-4" /> {d && d.status !== "resolved" ? "View dispute" : "Report / open dispute"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader><DialogTitle>Dispute — {o.orderNo}</DialogTitle></DialogHeader>
                      {d && d.status !== "resolved" ? (
                        <div className="space-y-3 text-sm">
                          <p><span className="text-muted-foreground">Reason:</span> {d.reason}</p>
                          {d.openerEvidence && <StorageImage storageKey={d.openerEvidence} alt="Evidence" className="max-h-40 rounded-lg border border-border object-contain" />}
                          {d.response ? (
                            <p><span className="text-muted-foreground">Response:</span> {d.response}</p>
                          ) : d.openedBy !== user?.id ? (
                            <>
                              <Textarea placeholder="Your response…" value={disputeResponse} onChange={(e) => setDisputeResponse(e.target.value)} rows={3} />
                              <Button className="w-full" disabled={disputeResponse.trim().length < 5 || respondDispute.isPending} onClick={() => respondDispute.mutate({ disputeId: d.id, response: disputeResponse })}>
                                Submit response
                              </Button>
                            </>
                          ) : (
                            <p className="text-muted-foreground">Waiting for the other party / admin review.</p>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <Textarea placeholder="Describe the problem (min 10 characters)…" value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)} rows={4} />
                          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border p-3 text-sm text-muted-foreground">
                            <Paperclip className="h-4 w-4" /> {disputeEvidence ? "Evidence attached ✓" : "Attach evidence (screenshot)"}
                            <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setDisputeEvidence(await uploadFile(f)); }} />
                          </label>
                          {openDispute.error && <p className="text-sm text-destructive">{openDispute.error.message}</p>}
                          <Button variant="destructive" className="w-full" disabled={disputeReason.trim().length < 10 || openDispute.isPending} onClick={() => openDispute.mutate({ orderId: o.id, reason: disputeReason, evidence: disputeEvidence ?? undefined })}>
                            Open dispute
                          </Button>
                        </div>
                      )}
                      {d?.status === "resolved" && <p className="text-sm">Resolved: <span className="font-medium text-primary">{d.resolution}</span> — {d.adminNote}</p>}
                    </DialogContent>
                  </Dialog>
                )}

                {/* Review */}
                {myRole === "buyer" && o.status === "completed" && !data.review && (
                  <Dialog>
                    <DialogTrigger asChild><Button variant="outline" className="w-full"><Star className="mr-2 h-4 w-4" /> Rate the seller</Button></DialogTrigger>
                    <DialogContent>
                      <DialogHeader><DialogTitle>Rate your purchase</DialogTitle></DialogHeader>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((n) => (
                          <button key={n} onClick={() => setRating(n)}>
                            <Star className={cn("h-8 w-8", n <= rating ? "fill-primary text-primary" : "text-muted")} />
                          </button>
                        ))}
                      </div>
                      <Textarea placeholder="How was the trade? (optional)" value={comment} onChange={(e) => setComment(e.target.value)} rows={3} />
                      <Button className="w-full" disabled={review.isPending} onClick={() => review.mutate({ orderId: o.id, rating, comment: comment || undefined })}>
                        Submit review
                      </Button>
                    </DialogContent>
                  </Dialog>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right: deal room chat */}
          <Card className="flex flex-col border-border bg-card lg:col-span-3" style={{ minHeight: 480 }}>
            <CardHeader className="border-b border-border">
              <CardTitle className="flex items-center gap-2 text-base">
                <ShieldCheck className="h-4 w-4 text-primary" /> Private deal room
                <span className="text-xs font-normal text-muted-foreground">buyer + seller + admin only</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-1 flex-col p-0">
              {!chatOpen ? (
                <div className="flex flex-1 items-center justify-center p-8 text-center text-sm text-muted-foreground">
                  {o.status === "awaiting_payment" || o.status === "payment_rejected"
                    ? <>Complete payment to open the deal room. <Link className="text-primary underline" to={`/checkout/${o.id}`}>Go to checkout</Link></>
                    : o.status === "payment_verification"
                      ? "Payment is being verified by the admin team. The deal room opens after approval."
                      : "Deal room unavailable for this order."}
                </div>
              ) : (
                <>
                  <div className="flex-1 space-y-3 overflow-y-auto p-4" style={{ maxHeight: 420 }}>
                    {msgs?.map((m) => (
                      <div key={m.id} className={cn("flex", m.isSystem ? "justify-center" : m.senderId === user?.id ? "justify-end" : "justify-start")}>
                        {m.isSystem ? (
                          <p className="max-w-md rounded-full bg-secondary px-4 py-1.5 text-center text-xs text-muted-foreground">{m.body}</p>
                        ) : (
                          <div className={cn(
                            "max-w-[80%] rounded-2xl px-4 py-2 text-sm",
                            m.senderId === user?.id ? "bg-primary text-primary-foreground" : "bg-secondary",
                          )}>
                            <p className="mb-0.5 text-[10px] opacity-70">
                              {m.sender?.name}{m.sender?.role === "admin" ? " (admin)" : ""} · {new Date(m.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                            </p>
                            <p className="whitespace-pre-wrap">{m.body}</p>
                            {m.attachment && <StorageImage storageKey={m.attachment} alt="attachment" className="mt-2 max-h-48 rounded-lg object-contain" />}
                          </div>
                        )}
                      </div>
                    ))}
                    <div ref={chatEnd} />
                  </div>
                  <div className="flex items-end gap-2 border-t border-border p-3">
                    <label className="cursor-pointer text-muted-foreground hover:text-primary">
                      <Paperclip className="h-5 w-5" />
                      <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setAttach(await uploadFile(f)); }} />
                    </label>
                    <div className="flex-1">
                      {attach && <p className="mb-1 text-xs text-primary">Screenshot attached ✓</p>}
                      <Input
                        value={msg}
                        onChange={(e) => setMsg(e.target.value)}
                        placeholder="Message the deal room…"
                        onKeyDown={(e) => { if (e.key === "Enter" && msg.trim()) send.mutate({ orderId: o.id, body: msg.trim(), attachment: attach ?? undefined }); }}
                      />
                    </div>
                    <Button size="icon" disabled={!msg.trim() || send.isPending || uploading} onClick={() => send.mutate({ orderId: o.id, body: msg.trim(), attachment: attach ?? undefined })}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

function Row({ k, v, mono, link }: { k: string; v?: string | null; mono?: boolean; link?: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="shrink-0 text-muted-foreground">{k}</span>
      {link && v ? (
        <Link to={link} className="text-right font-medium text-primary hover:underline">{v}</Link>
      ) : (
        <span className={cn("text-right font-medium", mono && "break-all font-mono text-xs")}>{v ?? "—"}</span>
      )}
    </div>
  );
}
