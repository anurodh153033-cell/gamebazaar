import { eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { games, users } from "./schema";
import { hashPassword } from "../api/lib/crypto";
import { ensureWallet } from "../api/lib/helpers";

const GAME_LIST = [
  { name: "Brawl Stars", sortOrder: 1 },
  { name: "Clash of Clans", sortOrder: 2 },
  { name: "Clash Royale", sortOrder: 3 },
  { name: "PUBG Mobile", sortOrder: 4 },
  { name: "BGMI", sortOrder: 5 },
  { name: "Fortnite", sortOrder: 6 },
  { name: "Roblox", sortOrder: 7 },
  { name: "Free Fire", sortOrder: 8 },
  { name: "Genshin Impact", sortOrder: 9 },
  { name: "Call of Duty Mobile", sortOrder: 10 },
];

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  for (const g of GAME_LIST) {
    const slug = g.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const existing = await db.query.games.findFirst({ where: eq(games.slug, slug) });
    if (!existing) {
      await db.insert(games).values({ ...g, slug, status: "active" });
      console.log(`  + game: ${g.name}`);
    }
  }

  // Admin account — change the password after first login
  const adminEmail = "admin@gamebazaar.io";
  const existingAdmin = await db.query.users.findFirst({
    where: eq(users.unionId, `local:${adminEmail}`),
  });
  if (!existingAdmin) {
    await db.insert(users).values({
      unionId: `local:${adminEmail}`,
      name: "GameBazaar Admin",
      email: adminEmail,
      passwordHash: hashPassword("GameBazaar#Admin1"),
      accountType: "both",
      role: "admin",
      isVerified: true,
      lastSignInAt: new Date(),
    });
    console.log("  + admin account:", adminEmail);
  }
  const admin = await db.query.users.findFirst({ where: eq(users.unionId, `local:${adminEmail}`) });
  if (admin) await ensureWallet(admin.id);

  console.log("Done.");
  process.exit(0);
}

seed();
